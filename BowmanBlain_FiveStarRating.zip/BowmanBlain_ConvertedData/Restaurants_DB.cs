﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowmanBlain_ConvertedData
{
    class Restaurants_DB
    {
        public List<Restaurantprofiles> restaurantprofiles { get; set; }
    };
}
